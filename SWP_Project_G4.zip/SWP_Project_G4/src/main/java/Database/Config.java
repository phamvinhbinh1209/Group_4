package Database;

public interface Config {
 // tự chỉnh theo máy
    String SERVER = "DESKTOP-QMKN1IJ\\SQLEXPRESS";
    String USER = "sa";
    String PASSWORD = "123";
    String DATABASE_NAME = "ShoeStore";
    int PORT = 1433;
}